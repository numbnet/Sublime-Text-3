---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: mfuentesg

---

**Describe the bug**
A clear and concise description of what the bug is.

**Desktop (please complete the following information):**
 - OS: [e.g. iOS]
 - Sublime Version [e.g. 22]

**Log file content with debug property in true**
Add any other context about the problem here.
