1. Install [UnitTesting](https://github.com/randy3k/UnitTesting) via Package Control.
2. Bring up command palette and choose **UnitTesting** command.
3. Enter the package name `PlainTasks` in the input panel and hit <kbd>Enter</kbd>, a console should popup and the tests should be running.

More docs in [UnitTesting-example](https://github.com/randy3k/UnitTesting-example)