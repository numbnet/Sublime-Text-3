class MissingCredentialsException(Exception):
    pass


class SimpleHTTPError(Exception):
    pass
