import sys
from os import path

sys.path.append(path.dirname(path.realpath(__file__)))
