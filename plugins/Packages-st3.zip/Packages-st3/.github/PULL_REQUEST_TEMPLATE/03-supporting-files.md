---
name: Update to supporting files
about: My changes do not include any `.sublime-syntax` file.
title: [PackageName] update_summary

---

- [ ] My commit messages start with the package name in square brackets, e.g. `[XML]`.
