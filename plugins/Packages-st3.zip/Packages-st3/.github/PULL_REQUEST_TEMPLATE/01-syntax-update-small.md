---
name: Small update to Syntax definition
about: I have made easily-reviewable changes to a `.sublime-syntax` file.
title: [PackageName] update_summary

---

- [ ] My commit messages start with the package name in square brackets, e.g. `[XML]`.
- [ ] I have included new or enhanced [syntax tests][] to cover the changes.

[syntax tests]: https://www.sublimetext.com/docs/3/syntax.html#testing
