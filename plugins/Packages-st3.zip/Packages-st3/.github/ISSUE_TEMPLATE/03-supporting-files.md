---
name: Snippet, Completion, Indentation, or Build problem
about: Suggest improvements for one of the default language support files.

---

<!--
    Please search existing issues to avoid creating duplicates. Also, if you
    are able, follow the directions at https://github.com/sublimehq/Packages#installation
    to check the latest version of this language highlighting.

    If the problem persists, please begin the issue title with the language in
    square brackets, e.g. "[PHP] Snippet for echo includes the wrong tab stops"
-->

- Sublime Version:
- OS Version:

## Expected behavior

## Actual behavior

## Steps to reproduce

1. 
2. 
