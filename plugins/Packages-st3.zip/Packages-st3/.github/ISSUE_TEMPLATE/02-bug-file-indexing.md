---
name: Go to Symbol problem
about: Create a bug report for file indexing in one of the default languages.

---

<!--
    Please search existing issues to avoid creating duplicates. Also, if you
    are able, follow the directions at https://github.com/sublimehq/Packages#installation
    to check the latest version of this language's behavior.

    If the problem persists, please begin the issue title with the language in
    square brackets, e.g. "[Java] Can't go-to-symbol on classes"
-->

- Sublime Version:
- OS Version:

## Expected behavior

## Actual behavior

## Steps to reproduce

1. 
2. 
