// SYNTAX TEST "Packages/JavaScript/JavaScript.sublime-syntax"

    XMLHttpRequest;
//  ^^^^^^^^^^^^^^ support.class.dom
    document;
//  ^^^^^^^^ support.type.object.dom
    window;
//  ^^^^^^ support.type.object.dom
    navigator;
//  ^^^^^^^^^ support.type.object.dom
    clearTimeout;
//  ^^^^^^^^^^^^ support.function.dom
    setTimeout;
//  ^^^^^^^^^^ support.function.dom
