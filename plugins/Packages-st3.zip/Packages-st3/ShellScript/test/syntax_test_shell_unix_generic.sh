# SYNTAX TEST "Packages/ShellScript/Shell-Unix-Generic.sublime-syntax"

[[ ]]
# <- support.function.double-brace.begin
 # <- support.function.double-brace.begin
 # ^^ support.function.double-brace.end

 # make sure the prototype is included
 # <- comment.line.number-sign punctuation.definition.comment.begin
 #^^^^^^^^ comment.line.number-sign
